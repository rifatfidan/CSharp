﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;

namespace Lottery_Software
{
    public partial class Form1 : Form
    {
        public Form1()
        {
            InitializeComponent();
        }

        private void rtxtMember_TextChanged(object sender, EventArgs e)
        {
            lbljoined.Text = rtxtMember.Lines.Count().ToString();
            if (rtxtMember.Lines.Count() > 0)
            {
                nselect.Maximum = rtxtMember.Lines.Count();
            }
            else
            {
                nselect.Minimum = 1;
            }
        }

        int chancecount = 1;
        private void Form1_Load(object sender, EventArgs e)
        {
            dtgList.ColumnCount = 2;
            dtgList.Columns[0].Name = "Item Numer";
            dtgList.Columns[1].Name = "Name";
        }

        private void btnStart_Click(object sender, EventArgs e)
        {

            int channum = Convert.ToInt32(nselect.Text);
            List<string> ListMembers = new List<string>(rtxtMember.Text.Split('\n'));
            if (rtxtMember.Text == "")
            {
                MessageBox.Show("Please enter members");
            }
            else
            {
                Random crea = new Random();
                for (int i = 0; i < channum; i++)
                {
                    int winner = crea.Next(0, ListMembers.Count);
                    dtgList.Rows.Add(chancecount++, ListMembers[winner]);
                    ListMembers.Remove(ListMembers[winner]);
                }
            }
        }

        private void btnClean_Click(object sender, EventArgs e)
        {
            rtxtMember.Clear();
            dtgList.Rows.Clear();
            chancecount = 1;
        }

        private void nselect_ValueChanged(object sender, EventArgs e)
        {
            nselect.Maximum = rtxtMember.Lines.Count();
        }
    }
}